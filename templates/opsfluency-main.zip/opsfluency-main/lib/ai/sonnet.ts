import "server-only";

import Anthropic from "@anthropic-ai/sdk";

import { getAdminClient } from "@/lib/supabase/admin";

/**
 * Single entry point for every Claude API call in OpsFluency.
 *
 * Per `CLAUDE.md` → "AI call conventions":
 * - 60s hard timeout via `AbortController` (180s for SOP conversion — see sop-conversion.ts)
 * - 1 retry on 429 / 5xx with jittered backoff (500–1500ms)
 * - Every call writes one `ai_call_log` row (model, tokens, duration, ids)
 * - Never log the full prompt or response at INFO level
 * - Callers never import `@anthropic-ai/sdk` directly
 *
 * Both Sonnet (quality-critical steps) and Haiku (structural conversion)
 * go through `callSonnet`. Pass `input.model` to select Haiku; omit for
 * Sonnet (default).
 */

export const SONNET_MODEL = "claude-sonnet-4-6";
export const HAIKU_MODEL = "claude-haiku-4-5-20251001";
const DEFAULT_TIMEOUT_MS = 180_000;
const MAX_RETRIES = 1;

let client: Anthropic | null = null;
function getClient(): Anthropic {
  if (!client) {
    client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
  }
  return client;
}

export type SonnetErrorCode =
  | "AI_TIMEOUT"
  | "AI_RATE_LIMITED"
  | "AI_PARSE_FAILURE"
  | "AI_TRUNCATED"
  | "AI_INTERNAL";

export interface SonnetSuccess<T> {
  ok: true;
  data: T;
  usage: { input_tokens: number; output_tokens: number };
}

export interface SonnetFailure {
  ok: false;
  error: {
    code: SonnetErrorCode;
    retry_allowed: boolean;
    message?: string;
    /** Up to 2KB of the raw response on parse failures, for debugging. */
    raw?: string;
    /** Wall time of the call, including retries. Useful for "is it slow or stuck?" */
    duration_ms?: number;
    /** 1-based attempt count when the failure surfaced. */
    attempt?: number;
    /** Model id (kept here so the error payload is fully self-describing). */
    model?: string;
  };
}

export type SonnetResult<T> = SonnetSuccess<T> | SonnetFailure;

export interface SonnetCallContext {
  /** The SOP being worked on, for cost attribution. Use `null` for non-SOP calls. */
  sopId: string | null;
  /** Always required — every AI call belongs to a tenant. */
  companyId: string;
}

/**
 * User message content. Accepts a plain string for text-only prompts or an
 * array of content blocks for vision (image) and document (PDF) prompts.
 * The Anthropic SDK accepts all three shapes in `messages[0].content`.
 */
export type SonnetUserContent =
  | string
  | Array<
      | { type: "text"; text: string }
      | {
          type: "image";
          source:
            | { type: "base64"; media_type: string; data: string }
            | { type: "url"; url: string };
        }
      | {
          type: "document";
          source: { type: "base64"; media_type: "application/pdf"; data: string };
        }
    >;

export interface SonnetCallInput<T> {
  systemPrompt: string;
  userMessage: SonnetUserContent;
  maxTokens: number;
  /** Extract structured output from the raw response text. Must throw on malformed input. */
  parse: (rawText: string) => T;
  /** Optional external signal; the timeout is applied in addition. */
  signal?: AbortSignal;
  /**
   * Which Claude model to use. Defaults to `SONNET_MODEL`.
   * Pass `HAIKU_MODEL` for structural / formatting tasks where reasoning
   * depth is less critical and throughput / cost matter more.
   */
  model?: string;
}

/**
 * Runs a single Claude API call with timeout, one retry on transient errors,
 * a parsing step, prompt caching on the system prompt, and a cost-log write.
 * Never throws for recognized failure modes — returns `{ ok: false, error }`
 * so callers can discriminate.
 */
export async function callSonnet<T>(
  input: SonnetCallInput<T>,
  ctx: SonnetCallContext,
): Promise<SonnetResult<T>> {
  const start = Date.now();
  const modelToUse = input.model ?? SONNET_MODEL;
  let lastError: unknown;

  // Cache the system prompt so repeat calls within the same session
  // (e.g. a manager uploading several SOPs) hit the cache after the
  // first write and pay 0.1× the input rate on those tokens.
  const systemBlocks: Anthropic.Messages.TextBlockParam[] = [
    {
      type: "text",
      text: input.systemPrompt,
      cache_control: { type: "ephemeral" },
    },
  ];

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), DEFAULT_TIMEOUT_MS);

    const signal = input.signal
      ? anySignal([input.signal, controller.signal])
      : controller.signal;

    try {
      const response = await getClient().messages.create(
        {
          model: modelToUse,
          max_tokens: input.maxTokens,
          system: systemBlocks,
          messages: [
            {
              role: "user",
              content: input.userMessage as Parameters<
                Anthropic["messages"]["create"]
              >[0]["messages"][number]["content"],
            },
          ],
        },
        { signal },
      );

      const rawText = response.content
        .filter((block) => block.type === "text")
        .map((block) => (block as { text: string }).text)
        .join("");

      // `max_tokens` truncation: Anthropic stopped mid-stream, so the JSON
      // is guaranteed broken. Surface this as its own code rather than
      // confusing the manager with a parse failure on a perfectly valid
      // partial response.
      if (response.stop_reason === "max_tokens") {
        await logCall({
          ctx,
          model: modelToUse,
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens,
          cacheWriteTokens: response.usage.cache_creation_input_tokens ?? 0,
          cacheReadTokens: response.usage.cache_read_input_tokens ?? 0,
          durationMs: Date.now() - start,
        });
        return {
          ok: false,
          error: {
            code: "AI_TRUNCATED",
            retry_allowed: false,
            message: `Model hit the ${input.maxTokens}-token output cap. Document is unusually long — split it or raise maxTokens.`,
            raw: rawText.slice(0, 2048),
            duration_ms: Date.now() - start,
            attempt: attempt + 1,
            model: modelToUse,
          },
        };
      }

      let parsed: T;
      try {
        parsed = input.parse(rawText);
      } catch {
        await logCall({
          ctx,
          model: modelToUse,
          inputTokens: response.usage.input_tokens,
          outputTokens: response.usage.output_tokens,
          cacheWriteTokens: response.usage.cache_creation_input_tokens ?? 0,
          cacheReadTokens: response.usage.cache_read_input_tokens ?? 0,
          durationMs: Date.now() - start,
        });
        return {
          ok: false,
          error: {
            code: "AI_PARSE_FAILURE",
            retry_allowed: true,
            raw: rawText.slice(0, 2048),
            duration_ms: Date.now() - start,
            attempt: attempt + 1,
            model: modelToUse,
          },
        };
      }

      await logCall({
        ctx,
        model: modelToUse,
        inputTokens: response.usage.input_tokens,
        outputTokens: response.usage.output_tokens,
        cacheWriteTokens: response.usage.cache_creation_input_tokens ?? 0,
        cacheReadTokens: response.usage.cache_read_input_tokens ?? 0,
        durationMs: Date.now() - start,
      });

      return {
        ok: true,
        data: parsed,
        usage: {
          input_tokens: response.usage.input_tokens,
          output_tokens: response.usage.output_tokens,
        },
      };
    } catch (err) {
      lastError = err;

      if (controller.signal.aborted && !input.signal?.aborted) {
        // No response.usage available — log zeros so the call count in the
        // console stays accurate even though the cost will be understated.
        await logCall({
          ctx,
          model: modelToUse,
          inputTokens: 0,
          outputTokens: 0,
          cacheWriteTokens: 0,
          cacheReadTokens: 0,
          durationMs: Date.now() - start,
        });
        return {
          ok: false,
          error: {
            code: "AI_TIMEOUT",
            retry_allowed: true,
            message: `Model did not respond within ${DEFAULT_TIMEOUT_MS / 1000}s`,
            duration_ms: Date.now() - start,
            attempt: attempt + 1,
            model: modelToUse,
          },
        };
      }

      if (shouldRetry(err) && attempt < MAX_RETRIES) {
        await sleep(500 + Math.floor(Math.random() * 1000));
        continue;
      }

      if (isRateLimited(err)) {
        return {
          ok: false,
          error: {
            code: "AI_RATE_LIMITED",
            retry_allowed: true,
            message: err instanceof Error ? err.message : "429 from Anthropic",
            duration_ms: Date.now() - start,
            attempt: attempt + 1,
            model: modelToUse,
          },
        };
      }

      return {
        ok: false,
        error: {
          code: "AI_INTERNAL",
          retry_allowed: false,
          message: err instanceof Error ? err.message : String(err),
          duration_ms: Date.now() - start,
          attempt: attempt + 1,
          model: modelToUse,
        },
      };
    } finally {
      clearTimeout(timeout);
    }
  }

  return {
    ok: false,
    error: {
      code: "AI_INTERNAL",
      retry_allowed: false,
      message: lastError instanceof Error ? lastError.message : String(lastError),
      duration_ms: Date.now() - start,
      attempt: MAX_RETRIES + 1,
      model: modelToUse,
    },
  };
}

function shouldRetry(err: unknown): boolean {
  if (err instanceof Anthropic.APIError) {
    return err.status === 429 || (err.status !== undefined && err.status >= 500);
  }
  return false;
}

function isRateLimited(err: unknown): boolean {
  return err instanceof Anthropic.APIError && err.status === 429;
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Cross-compatibility helper for Node versions without `AbortSignal.any`.
 * Combines multiple signals so aborting any of them aborts the returned one.
 */
function anySignal(signals: AbortSignal[]): AbortSignal {
  if (typeof AbortSignal.any === "function") return AbortSignal.any(signals);
  const controller = new AbortController();
  for (const s of signals) {
    if (s.aborted) {
      controller.abort(s.reason);
      break;
    }
    s.addEventListener("abort", () => controller.abort(s.reason), { once: true });
  }
  return controller.signal;
}

interface LogCallInput {
  ctx: SonnetCallContext;
  model: string;
  inputTokens: number;
  outputTokens: number;
  cacheWriteTokens: number;
  cacheReadTokens: number;
  durationMs: number;
}

/**
 * Writes an `ai_call_log` row. Uses the admin client because this runs
 * outside any user-facing transaction and must not be gated by RLS — we
 * always want to capture cost data even when a call ultimately fails for
 * an authorization reason.
 */
async function logCall({
  ctx,
  model,
  inputTokens,
  outputTokens,
  cacheWriteTokens,
  cacheReadTokens,
  durationMs,
}: LogCallInput): Promise<void> {
  try {
    const supabase = getAdminClient();
    await supabase.from("ai_call_log").insert({
      model,
      input_units: inputTokens,
      output_units: outputTokens,
      cache_write_tokens: cacheWriteTokens,
      cache_read_tokens: cacheReadTokens,
      unit_kind: "token",
      sop_id: ctx.sopId,
      company_id: ctx.companyId,
      duration_ms: durationMs,
    });
  } catch {
    // Telemetry must never fail the main call.
  }
}
