Copyright (c) 2026 OpsFluency&trade;. All rights reserved.

This software and its source code are proprietary and confidential.
Unauthorized copying, modification, distribution, or use of this
software, in whole or in part, via any medium, is strictly prohibited
without the express written permission of the copyright owner.
